/**
 * Model: Contains all the state and logic
 * Does not contain anything about images or graphics, must ask view for that
 *
 * has methods to
 *  detect collision with boundaries
 * decide next direction
 * provide direction
 * provide location
 **/




//CISC275-010 - Lab 4
// Author: Justin Havel
// TA: Mehak Gupta
// DUE: 3/10/2019

public class Model {
	private int xloc = 0;
    private int yloc = 0;
    private final int xIncr = 8;
    private final int yIncr = 2;
    private int frameWidth = 500;
    private int frameHeight = 300;
    private int imgWidth = 165;
    private int imgHeight = 165;
    private int xIncDec = 1;
    private int yIncDec = 1;
    private int direction;
    
	private int NORTHEAST = 4;
	private int SOUTHEAST = 5;
	private int SOUTHWEST = 7;
	private int NORTHWEST = 6;
    
    //Model(view.getWidth(), view.getHeight()), view.getImageWidth(), view.getImageHeight());
    
    public Model(int width, int height, int imgWidth, int imgHeight) {
    	this.frameWidth = width;
    	this.frameHeight = height;
    	this.imgWidth = imgWidth;
    	this.imgHeight = imgHeight;
    }
    
    
    public int getX() {
    	return xloc;
    }
    public int getY() {
    	return yloc;
    }
    public int getDirect() {
    	return direction;
    }
    
    
    
    public void updateLocationAndDirection() {
    	xloc+=(xIncr * xIncDec);
    	yloc+= (yIncr*yIncDec);
    	
	   	if (xloc + imgWidth >= frameWidth) {
	   		xIncDec = -1;
	   	}
	   	if (xloc <= 0) {
	   		xIncDec = 1;
	   	}
	   	if (yloc <= 0) {
	   		yIncDec = 1;
	   	}
	   	if (yloc + imgHeight >= frameHeight) {
	   		yIncDec = -1;
	   	}
	    if (xIncDec == 1 && yIncDec == 1) {
	   		direction = SOUTHEAST;
	   	}
	   	if (xIncDec == 1 && yIncDec == -1) {
	   		direction = NORTHEAST;
	   	}
	   	if (xIncDec == -1 && yIncDec == 1) {
	   		direction = SOUTHWEST;
	   	}
	   	if (xIncDec == -1 && yIncDec == -1) {
	   		direction = NORTHWEST;
	   	}
    }
	
}
