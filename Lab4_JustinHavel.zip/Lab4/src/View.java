import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * View: Contains everything about graphics and images
 * Know size of world, which images to load etc
 *
 * has methods to
 * provide boundaries
 * use proper images for direction
 * load images for all direction (an image should only be loaded once!!! why?)
 **/


//CISC275-010 - Lab 4
//Author: Justin Havel
//TA: Mehak Gupta
//DUE: 3/10/2019



public class View extends JPanel {
	
	private final int frameCount = 10;
    private int picNum = 0;
    BufferedImage[] pics;
    private int xorc = 0;
    private int yorc = 0;
    private int orcDirect;
    private final int xIncr = 8;
    private int frameWidth = 500;
    private int frameHeight = 300;
    private int imgWidth = 165;
    private int imgHeight = 165;
    BufferedImage[][] choosePic;
     
    
    
    public int getImageHeight() {
		return imgHeight;
	}

	public int getImageWidth() {
		return imgWidth;
	}
    
	
	
	public View() {
		JFrame frame = new JFrame();
	    frame.getContentPane().add(this);
	    frame.setBackground(Color.gray);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(frameWidth, frameHeight);
	    frame.setVisible(true);	
	
		pics = new BufferedImage[10];
    	pics[0] = createImage("orc_forward_southeast.png");
    	pics[1] = createImage("orc_forward_east.png");
    	pics[2] = createImage("orc_forward_north.png");
    	pics[3] = createImage("orc_forward_northeast.png");
    	pics[4] = createImage("orc_forward_northwest.png");
    	pics[5] = createImage("orc_forward_south.png");
    	pics[6] = createImage("orc_forward_southwest.png");
    	pics[7] = createImage("orc_forward_west.png");
    	
    	choosePic = new BufferedImage[8][10];
		for (int i = 0; i < xIncr; i++) {
			for (int j = 0; j < frameCount; j++) {
				choosePic[i][j] = pics[i].getSubimage(imgWidth*j, 0, imgWidth, imgHeight);
			}
		}
    	
	}
	
	
	
	public void paint(Graphics g) {
		picNum = (picNum + 1) % frameCount;
		g.drawImage(choosePic[orcDirect][picNum], xorc, yorc, Color.gray, this);
		
	}
	
	
	
	public void update(int x, int y, int direction) {
		try {
			xorc = x;
			yorc = y;
			orcDirect = direction;
			setBackground(Color.gray);
			repaint();
			Thread.sleep(100);
		} catch (InterruptedException e)	{
			e.printStackTrace();
		}
	}
	
    
	
    private BufferedImage createImage(String fname){
    	BufferedImage bufferedImage;
    	
    	try {
    		bufferedImage = ImageIO.read(new File(fname));
    		return bufferedImage;
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    	return null;
    }
    
    
    
    
    public static void main(String[] args) {
		Controller myC = new Controller();
    	myC.start();
    }
}